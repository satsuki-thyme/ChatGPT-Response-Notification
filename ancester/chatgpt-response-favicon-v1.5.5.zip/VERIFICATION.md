# v1.5.5診断候補の再現検証

対象は本ZIPの`verification/candidate-1.5.5/chatgpt-response-favicon.user.js`。版番号のない作業領域の1.5.4とは別の検証対象。

Node.js 24以降を用意し、ZIPの展開先で次を実行する。

```sh
npm ci --ignore-scripts --no-audit --no-fund
npm test
```

`verify.cjs`はOSの一時ディレクトリに検証用コピーを作り、構文検査、既存113件、回答検出16件、使用状況診断19件を順に実行する。同梱の結果ファイルを上書きしない。合計148件。jsdomは30.1.1で固定。

今回の実行ログと結果は`verification-results-2026-11-15/`。`verification/verified-base/`は1.5.3で過去の回答検出漏れを再現する比較対象であり、導入するコードではない。`verification/candidate-1.5.5/evidence/`は前回採取されたDOMの構造・ラベルのみを含み、試験中の本文と時刻は合成。

通知・再読み込み・時計・タブ共有記録は模擬。Windowsや実際のChatGPTでの成功を示す試験ではない。今回提出された実機診断の原文は`evidence/usage-diagnostic-v1.5.4-2026-11-15.json`に分けて収録。

全ファイルのサイズとSHA-256は`MANIFEST.json`。版番号付きJS/TXTと検証対象JSは同一バイト列。導入と実機採取は`USAGE_DIAGNOSTICS-v1.5.5.md`に従う。
