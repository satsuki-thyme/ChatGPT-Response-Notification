const fs = require('node:fs');
const assert = require('node:assert/strict');
const { JSDOM } = require('jsdom');
const source = fs.readFileSync(__dirname + '/../chatgpt-response-favicon.user.js', 'utf8');
const ORIGINAL = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aL1sAAAAASUVORK5CYII=';
const NEXT = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg"/%3E';
const article = (id, text, copy = true) => `<article data-testid="conversation-turn-${id}"><section data-turn="assistant"><div data-message-author-role="assistant" data-message-id="${id}">${text}</div></section>${copy ? '<button data-testid="copy-turn-action-button">Copy</button>' : ''}</article>`;
const workAnswer = (id, text, actions = true) => `<div class="contents"><div id="work-${id}" class="group flex flex-col"><div class="whitespace-pre-wrap">${text}</div>${actions ? '<div class="mt-1.5 flex turn-action-controls min-h-5 min-w-0"><div class="flex turn-action-controls items-center gap-0.5"><span class="contents" data-state="closed"><button type="button" aria-label="メッセージをコピーする"><svg></svg></button></span></div><div class="flex min-h-5 min-w-0"><button type="button" aria-label="回答を再生成" data-state="closed"><svg></svg></button></div></div>' : ''}</div></div>`;
const workUser = text => `<div class="flex flex-col"><div>${text}</div><div class="flex flex-row-reverse items-center gap-1"><div class="isolate me-1 ms-1 flex items-center gap-2 opacity-0 group-focus-within/user-message:opacity-100 group-hover/user-message:opacity-100"><div class="flex turn-action-controls items-center gap-0.5"><span class="contents" data-state="closed"><button type="button" aria-label="メッセージをコピーする"><svg></svg></button></span></div></div></div></div>`;
let browser;
const results = [];

async function fixture({ clockStart = 0, empty = false, pathname = '/c/current', noIcons = false, work = false, richLabel = 'Work モードで作成', usageHTML = null, session = {}, preferences = {}, desktopAvailable = true, desktopThrows = false, shared = null, locksAvailable = true, localStorageThrows = false } = {}) {
    const dom = new JSDOM(`<!doctype html><html><head>${noIcons ? '' : `<link id="original" rel="icon" href="${ORIGINAL}" type="image/png" sizes="32x32"><link id="touch" rel="apple-touch-icon" href="/touch.png">`}</head><body><main id="conversation">${empty ? '' : work ? workUser('Old question') + workAnswer('a0','Old response') : article('a0','Old response')}</main>${work ? `<section id="work-composer"><div id="work-editor" class="ProseMirror ProseMirror-focused" role="textbox" aria-label="${richLabel}" contenteditable="true">test prompt</div><button type="button" aria-label="送信"><svg></svg></button><div id="stop-host"></div></section>` : '<form data-chatgpt-composer><div id="prompt-textarea" contenteditable="true">test prompt</div><button type="button" data-testid="send-button">Send</button><div id="stop-host"></div></form>'}</body></html>`,{url:'https://chatgpt.com'+pathname,runScripts:'outside-only'});
    const w=dom.window,d=w.document;
    w.testHidden=true;
    Object.defineProperty(d,'visibilityState',{configurable:true,get:()=>w.testHidden?'hidden':'visible'});
    Object.defineProperty(d,'hasFocus',{configurable:true,value:()=>false});
    w.Element.prototype.getClientRects=function(){
        for(let node=this;node;node=node.parentElement)if(node.hidden || node.style.display==='none')return [];
        return [{width:10,height:10}];
    };
    w.matchMedia=()=>({matches:true});
    w.testAlerts=[];w.alert=text=>w.testAlerts.push(text);w.prompt=(title,text)=>{w.testPrompt=text;return null;};w.testMenus={};
    const sharedState = shared || { values: new Map(), locked: false };
    Object.defineProperty(w, 'localStorage', { configurable: true, value: {
        getItem(key) { if(localStorageThrows)throw Error('Storage blocked');return sharedState.values.get(key) ?? null; },
        setItem(key,value) { if(localStorageThrows)throw Error('Storage blocked');sharedState.values.set(key,String(value)); },
        removeItem(key) { sharedState.values.delete(key); }
    }});
    if(locksAvailable)Object.defineProperty(w.navigator, 'locks', { configurable:true, value: {
        request(name, options, callback) { return Promise.resolve().then(() => {
            if(sharedState.locked)return callback(null);
            sharedState.locked=true;
            try { return callback({ name }); } finally { sharedState.locked=false; }
        }); }
    }});
    w.testNotifications=[];w.testPreferences={...preferences};w.testFocus=0;
    w.focus=()=>w.testFocus++;
    w.GM_getValue=(key,fallback)=>Object.hasOwn(w.testPreferences,key)?w.testPreferences[key]:fallback;
    w.GM_setValue=(key,value)=>{w.testPreferences[key]=value;};
    if(desktopAvailable)w.GM_notification=details=>{if(desktopThrows)throw Error('Notification rejected');w.testNotifications.push(details);};
    for(const [key,value] of Object.entries(session))w.sessionStorage.setItem(key,value);
    if(usageHTML!==null){d.body.innerHTML=usageHTML;}
    w.testReloads=0;
    const locationImpl=require('jsdom/lib/generated/idl/utils').implForWrapper(w.location);
    locationImpl.reload=()=>{w.testReloads++;};
    w.GM_registerMenuCommand=(name,fn)=>{w.testMenus[name]=fn;return name;};
    w.GM_unregisterMenuCommand=name=>delete w.testMenus[name];
    d.querySelector('form')?.addEventListener('submit',event=>event.preventDefault());
    w.testIconMutations=0;
    new w.MutationObserver(records=>w.testIconMutations+=records.length).observe(d.head,{attributes:true,childList:true,subtree:true});
    let now=clockStart,seq=0;const timers=new Map();
    Object.defineProperty(w.performance,'now',{value:()=>now});
    w.Date.now=()=>1790856000000+now;
    const add=(fn,ms,args,repeat)=>{const id=++seq;timers.set(id,{fn,args,due:now+Math.max(1,Number(ms)||0),repeat});return id;};
    w.setTimeout=(fn,ms,...args)=>add(fn,ms,args,0);w.clearTimeout=id=>timers.delete(id);
    w.setInterval=(fn,ms,...args)=>add(fn,ms,args,Math.max(1,Number(ms)||0));w.clearInterval=id=>timers.delete(id);
    const flush=async()=>{await Promise.resolve();await Promise.resolve();await Promise.resolve();};
    async function runFor(ms){
        const end=now+ms;await flush();let iterations=0;
        while(true){
            const next=[...timers].filter(([,t])=>t.due<=end).sort((a,b)=>a[1].due-b[1].due)[0];if(!next)break;
            if(++iterations>10000)throw Error('Timer loop');const [id,t]=next;now=t.due;
            if(t.repeat)t.due+=t.repeat;else timers.delete(id);t.fn(...t.args);await flush();
        }
        now=end;await flush();
    }
    w.eval(source);await flush();
    return {
        evaluate(fn,arg){const value=w.Function('arg',`return (${fn.toString()})(arg);`)(arg);return Promise.resolve(value !== null && typeof value === 'object' ? JSON.parse(JSON.stringify(value)) : value);},
        clock:{runFor, async observed(ms){
            // 監視が動き続ける経過。jumpは実際の監視空白を再現するため残す。
            while(ms>0){const step=Math.min(ms,60000);await this.jump(step);ms-=step;}
        }, async jump(ms){
            await flush();now+=ms;
            for(const timer of timers.values())if(timer.due<now)timer.due=now;
            await runFor(1);
        }},
        locator(selector){return {count:async()=>d.querySelectorAll(selector).length,getAttribute:async name=>d.querySelector(selector).getAttribute(name),evaluate:async fn=>fn(d.querySelector(selector))};},
        async close(){w.__chatgptResponseFaviconV2?.dispose();w.close();}
    };
}

async function hidden(page, value) {
    await page.evaluate(value => {window.testHidden=value;document.dispatchEvent(new Event('visibilitychange'));},value);
}
async function streaming(page, value, label = 'Stop streaming') {
    await page.evaluate(({value,label}) => {
        document.getElementById('stop-host').innerHTML = value ? `<button type="button" data-testid="stop-button" aria-label="${label}">Stop</button>` : '';
    },{value,label});
    await page.clock.runFor(100);
}
async function output(page, id, text, copy = true) {
    await page.evaluate(html => document.getElementById('conversation').insertAdjacentHTML('beforeend',html),article(id,text,copy));
    await page.clock.runFor(100);
}
async function notified(page) {return page.evaluate(() => window.__chatgptResponseFaviconV2.inspect().notified);}
async function send(page) {await page.evaluate(() => document.querySelector('[data-testid="send-button"]').click());}
async function assertOriginal(page, expected = ORIGINAL) {
    const actual = await page.evaluate(() => {
        const link = document.getElementById('original');
        return {href:link.getAttribute('href'),type:link.getAttribute('type'),sizes:link.getAttribute('sizes'),touch:document.getElementById('touch').getAttribute('href'),custom:!!document.getElementById('chatgpt-response-favicon')};
    });
    assert.deepEqual(actual,{href:expected,type:'image/png',sizes:'32x32',touch:'/touch.png',custom:false});
}
async function test(name, fn) {
    try { await fn(); results.push({name,result:'PASS'}); console.log('PASS',name); }
    catch (error) {results.push({name,result:'FAIL',error:error.message});console.error('FAIL',name,error);}
}


module.exports = { fixture, hidden, streaming, output, send, workAnswer };
