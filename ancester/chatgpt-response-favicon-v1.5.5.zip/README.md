# ChatGPT Response Notification：v1.5.5診断候補

使用状況を開くまで回復通知が来ない問題の原因採取用です。遅延修正済みとは扱いません。

導入と約90秒の採取手順は[USAGE_DIAGNOSTICS-v1.5.5.md](USAGE_DIAGNOSTICS-v1.5.5.md)。コードは`chatgpt-response-favicon-v1.5.5.user.js`と同内容の`.user.txt`。既存Tampermonkeyスクリプトへ入れ替えます。

模擬148件合格。Windows実機は未確認。再現方法は[VERIFICATION.md](VERIFICATION.md)。`verification/verified-base/`の1.5.3は比較試験用で、導入対象ではありません。
