'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { fixture, hidden } = require('./investigation-fixture.cjs');
const KEY = 'chatgpt-response-favicon:usage-trace:v1';
const BASE = 1790856000000;
const source = fs.readFileSync(__dirname + '/../chatgpt-response-favicon.user.js', 'utf8');
const card = remaining => `<main><section><h2>5-hour limit</h2><p class="metric">${remaining}% remaining</p></section></main>`;
const usage = (remaining = 30, options = {}) => fixture({ pathname: '/settings/usage?tab=overview', usageHTML: card(remaining), ...options });
const inspect = p => p.evaluate(() => ({ ...window.__chatgptResponseFaviconV2.inspectUsage(),
    reloads: window.testReloads, notifications: window.testNotifications.length }));
const results = [];
async function test(name, fn) {
    try { await fn(); results.push({ name, result: 'PASS' }); console.log('PASS', name); }
    catch (error) { results.push({ name, result: 'FAIL', error: error.stack }); console.error('FAIL', name, error); }
}
async function using(promise, fn) { const p = await promise; try { await fn(p); } finally { await p.close(); } }
async function recovered(p) {
    await p.clock.runFor(3500);
    await p.evaluate(() => { document.querySelector('.metric').textContent = '35% remaining'; });
    await p.clock.runFor(4000);
}

(async () => {
    await test('Hidden state survives opening the tab; available initial state emits no recovery', () => using(usage(), async p => {
        await p.clock.runFor(3500); await hidden(p, false); await p.clock.runFor(1500);
        const d = await inspect(p);
        assert.equal(d.version, '1.5.6'); assert.equal(d.reloadBlockedBy, 'visible');
        assert.equal(d.usageTrace.lastHiddenObservation.visibility, 'hidden');
        assert.equal(d.usageTrace.lastHiddenObservation.reloadBlockedBy, null);
        assert.equal(d.usageTrace.lastHiddenObservation.routeKind, 'usage-path');
        assert.ok(d.usageTrace.lastHiddenObservation.snapshotAt <= d.lastUsageScanAt);
        assert.equal(d.notifications, 0);
    }));
    await test('Conversation-hosted usage remains protected and records its hidden suppression', () => using(usage(30, {
        pathname: '/c/private-conversation-id#settings/Usage'
    }), async p => {
        await p.clock.runFor(65000); await hidden(p, false); await p.clock.runFor(1500);
        const d = await inspect(p);
        assert.equal(d.reloads, 0); assert.equal(d.routeKind, 'conversation-usage');
        assert.equal(d.usageTrace.lastHiddenObservation.reloadBlockedBy, 'conversation-route');
        assert.ok(!JSON.stringify(d.usageTrace).includes('private-conversation-id'));
    }));
    await test('Non-conversation hash usage is classified without storing its URL', () => using(usage(30, {
        pathname: '/#settings/Usage'
    }), async p => {
        await p.clock.runFor(65000); const d = await inspect(p);
        assert.equal(d.routeKind, 'usage-hash'); assert.equal(d.reloads, 1);
        assert.ok(d.usageTrace.events.some(e => e.event === 'reload-request'));
    }));
    await test('Unsent input is preserved and prevents reload; contents never enter trace', () => using(usage(30, {
        usageHTML: card(30) + '<textarea>PRIVATE DRAFT</textarea>'
    }), async p => {
        await p.clock.runFor(65000); const d = await inspect(p);
        assert.equal(d.reloads, 0); assert.equal(d.usageTrace.lastHiddenObservation.reloadBlockedBy, 'unsent-input');
        assert.ok(!JSON.stringify(d.usageTrace).includes('PRIVATE DRAFT'));
        assert.equal(await p.evaluate(() => document.querySelector('textarea').value), 'PRIVATE DRAFT');
    }));
    await test('Reload request and subsequent document start remain distinct across session storage', async () => {
        let session;
        await using(usage(), async p => {
            await p.clock.runFor(65000);
            assert.equal((await inspect(p)).reloads, 1);
            session = await p.evaluate(() => Object.fromEntries(Object.entries(sessionStorage)));
        });
        await using(usage(30, { session, clockStart: 70000 }), async p => {
            await p.clock.runFor(3500); const d = await inspect(p);
            const request = d.usageTrace.events.find(e => e.event === 'reload-request');
            const start = d.usageTrace.events.findLast(e => e.event === 'entered');
            assert.ok(request); assert.ok(start); assert.ok(start.runStartedAt > request.runStartedAt);
            assert.equal(d.usageTrace.readStatus, 'loaded'); assert.equal(d.notifications, 0);
        });
    });
    await test('Usage monitoring gap records both clocks and observation endpoints', () => using(usage(), async p => {
        await p.clock.runFor(3500); await p.clock.jump(180000); const d = await inspect(p);
        const gap = d.usageTrace.lastGap;
        assert.ok(gap.wallGapMs >= 180000); assert.ok(gap.monotonicGapMs >= 180000);
        assert.equal(gap.fromRouteKind, 'usage-path'); assert.equal(gap.toRouteKind, 'usage-path');
        assert.equal(gap.fromVisibility, 'hidden'); assert.equal(gap.toVisibility, 'hidden');
        assert.ok(gap.toAt > gap.fromAt); assert.equal(d.notifications, 0);
    }));
    await test('Earlier conversation gap is not presented as a usage-screen gap', () => using(fixture(), async p => {
        await p.clock.jump(200000);
        assert.equal(await p.evaluate(key => sessionStorage.getItem(key), KEY), null);
        await p.evaluate(html => { history.pushState({}, '', '/settings/usage'); document.body.innerHTML = html; }, card(30));
        await p.clock.runFor(3500); const d = await inspect(p);
        assert.equal(d.observationClock.lastGap.fromRouteKind, 'conversation');
        assert.equal(d.observationClock.lastGap.toRouteKind, 'conversation');
        assert.equal(d.usageTrace.lastGap, null);
    }));
    await test('A gap crossing into usage records both route categories', () => using(fixture(), async p => {
        await p.clock.runFor(500);
        await p.evaluate(html => { history.pushState({}, '', '/settings/usage'); document.body.innerHTML = html; }, card(30));
        await p.clock.jump(180000); const d = await inspect(p);
        assert.equal(d.usageTrace.lastGap.fromRouteKind, 'conversation');
        assert.equal(d.usageTrace.lastGap.toRouteKind, 'usage-path');
    }));
    await test('Wall-clock jump is recorded separately from monotonic elapsed time', () => using(usage(), async p => {
        await p.clock.runFor(1500);
        await p.evaluate(base => { Date.now = () => base + performance.now() + 3600000; }, BASE);
        await p.clock.runFor(500); const gap = (await inspect(p)).observationClock.lastGap;
        assert.equal(gap.wallGapMs, 3600500); assert.equal(gap.monotonicGapMs, 500);
    }));
    await test('Backward clock adjustment is not discarded or classified as recovery', () => using(usage(), async p => {
        await p.clock.runFor(1500);
        await p.evaluate(base => { Date.now = () => base + performance.now() - 3600000; }, BASE);
        await p.clock.runFor(500); const d = await inspect(p);
        assert.equal(d.usageTrace.lastGap.wallGapMs, -3599500); assert.equal(d.notifications, 0);
    }));
    await test('Trace is bounded and does not grow with repeated events', () => using(usage(), async p => {
        await p.evaluate(() => { for (let i = 0; i < 80; i++) window.dispatchEvent(new Event(i % 2 ? 'online' : 'offline')); });
        const d = await inspect(p);
        assert.equal(d.usageTrace.events.length, 48);
        assert.ok((await p.evaluate(key => sessionStorage.getItem(key).length, KEY)) < 131072);
    }));
    await test('Stored trace is sanitized; unknown strings, URLs, labels and properties are excluded', () => {
        const injected = { event: 'sample', at: BASE - 1000, visibility: 'hidden', routeKind: 'PRIVATE URL',
            status: 'recognized', rows: [{ key: 'hours-5', state: 'available', remaining: 30, label: 'PRIVATE LABEL' },
                { key: 'PRIVATE KEY', state: 'blocked' }], body: 'PRIVATE BODY',
            gap: { fromAt: BASE - 2000, toAt: BASE - 1000, fromRouteKind: 'PRIVATE URL', text: 'PRIVATE BODY' } };
        return using(usage(30, { session: { [KEY]: JSON.stringify({ version: 1, updatedAt: BASE - 1000,
            events: [injected], lastHidden: injected, lastGap: injected.gap, private: 'PRIVATE SECRET' }) } }), async p => {
            const d = await inspect(p); assert.ok(!JSON.stringify(d.usageTrace).includes('PRIVATE'));
            assert.equal(d.usageTrace.events[0].rows.length, 1);
        });
    });
    await test('Expired history is ignored', () => using(usage(30, { session: { [KEY]: JSON.stringify({
        version: 1, updatedAt: BASE - 86400001, events: [{ event: 'reload-request', at: BASE - 86400001 }],
        lastHidden: { event: 'sample', at: BASE - 86400001, visibility: 'hidden' },
        lastGap: { fromAt: BASE - 90000000, toAt: BASE - 86400001, wallGapMs: 3599999 }
    }) } }), async p => {
        const d = await inspect(p); assert.equal(d.usageTrace.lastGap, null);
        assert.equal(d.usageTrace.events.length, 1); assert.equal(d.usageTrace.events[0].event, 'entered');
    }));
    await test('Malformed trace never prevents actual blocked-to-available handling', () => using(usage(0, {
        session: { [KEY]: '{' }
    }), async p => {
        await recovered(p); const d = await inspect(p);
        assert.equal(d.notifications, 1); assert.equal(d.lastDesktop.kind, 'usage');
        assert.equal(d.usageTrace.readStatus, 'unavailable-or-invalid');
        assert.ok(d.usageTrace.events.some(e => e.event === 'recovery-result' && e.recoveryCoordination === 'requested'));
    }));
    await test('Trace storage failure is isolated from existing usage state and recovery notification', () => using(usage(0), async p => {
        await p.evaluate(({ key, source }) => {
            const get = Storage.prototype.getItem, set = Storage.prototype.setItem;
            Storage.prototype.getItem = function(k) { if (k === key) throw Error('Trace unavailable'); return get.call(this, k); };
            Storage.prototype.setItem = function(k, v) { if (k === key) throw Error('Trace unavailable'); return set.call(this, k, v); };
            window.eval(source);
        }, { key: KEY, source });
        await recovered(p); const d = await inspect(p);
        assert.equal(d.notifications, 1); assert.equal(d.savedState, true);
        assert.equal(d.usageTrace.readStatus, 'unavailable-or-invalid'); assert.equal(d.usageTrace.writeStatus, 'unavailable');
    }));
    await test('Lifecycle events and offline blocking are retained without forced reload', () => using(usage(), async p => {
        await p.evaluate(() => {
            Object.defineProperty(navigator, 'onLine', { configurable: true, value: false });
            window.dispatchEvent(new Event('offline')); document.dispatchEvent(new Event('freeze'));
        });
        await p.clock.jump(180000);
        await p.evaluate(() => { document.dispatchEvent(new Event('resume')); window.dispatchEvent(new Event('pagehide')); });
        const d = await inspect(p); const events = d.usageTrace.events.map(e => e.event);
        for (const event of ['offline', 'freeze', 'resume', 'pagehide']) assert.ok(events.includes(event));
        assert.equal(d.reloads, 0); assert.equal(d.usageTrace.lastHiddenObservation.reloadBlockedBy, 'offline');
    }));
    await test('Returned diagnostics cannot mutate retained history', () => using(usage(), async p => {
        await p.evaluate(() => {
            const d = window.__chatgptResponseFaviconV2.inspectUsage();
            d.usageTrace.events[0].rows[0].remaining = 99; d.usageTrace.events.length = 0;
        });
        const d = await inspect(p); assert.equal(d.usageTrace.events[0].rows[0].remaining, 30);
    }));
    await test('Reinjection disposes prior listeners and monitoring; visible tab is never reloaded', () => using(usage(), async p => {
        await p.evaluate(source => window.eval(source), source);
        await hidden(p, false); await p.clock.runFor(65000); const d = await inspect(p);
        assert.equal(d.reloads, 0); assert.equal(d.usageTrace.events.filter(e => e.event === 'visibility').length, 1);
        assert.equal(d.notifications, 0);
    }));
    await test('Leaving usage stops persisted sampling on conversation pages', () => using(usage(), async p => {
        await p.clock.runFor(3500);
        await p.evaluate(() => { history.pushState({}, '', '/c/another-private-id'); });
        await p.clock.runFor(1500); const before = await p.evaluate(key => sessionStorage.getItem(key), KEY);
        await p.clock.runFor(35000); await hidden(p, false); await p.clock.runFor(1000);
        const after = await p.evaluate(key => sessionStorage.getItem(key), KEY);
        assert.equal(before, after); assert.ok(!after.includes('another-private-id'));
        assert.equal((await inspect(p)).usageTrace.events.at(-1).event, 'left');
    }));
    const output = { sourceSHA256: crypto.createHash('sha256').update(source).digest('hex'), runtime: process.version,
        jsdom: require('jsdom/package.json').version, scope: 'Synthetic DOM, clock and storage; mocked reload/notifications; not Windows physical evidence',
        passed: results.filter(r => r.result === 'PASS').length, total: results.length, results };
    fs.writeFileSync(__dirname + '/usage-trace-results.json', JSON.stringify(output, null, 2) + '\n', { flag: 'wx' });
    console.log(`${output.passed}/${output.total} passed`); process.exitCode = output.passed === output.total ? 0 : 1;
})().catch(error => { console.error(error); process.exitCode = 1; });
