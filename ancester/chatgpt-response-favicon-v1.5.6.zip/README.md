# ChatGPT Response Notification：1.5.6診断候補

長い診断JSONが中央省略される問題を修正した候補です。回復通知の遅延原因は未確定です。

導入と採取: [USAGE_DIAGNOSTICS-v1.5.6.md](USAGE_DIAGNOSTICS-v1.5.6.md)。既存Tampermonkeyスクリプトに版番号付きJSまたはTXTを入れ替えます。通常配布の1.5.4は別途維持しています。

模擬155件合格。実ブラウザは起動制限で未実施。再現手順は[VERIFICATION.md](VERIFICATION.md)。比較用のverified-base/1.5.3は導入対象ではありません。
