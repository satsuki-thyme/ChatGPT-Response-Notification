# 1.5.6の検証

Node.js 24以降で展開先に移動し、次を実行します。

```sh
npm ci --ignore-scripts --no-audit --no-fund
npm test
```

構文検査、既存113件、回答検出16件、履歴19件、診断画面7件の計155件を、一時ディレクトリで実行します。同梱の結果を上書きしません。依存jsdomは30.1.1です。今回の結果はverification-results-2026-11-15/にあります。これらのdialog開閉APIは模擬です。

## 任意の実ブラウザ試験

verify-browser.cjsは隔離したChromiumと合成ページで、全文のCtrl+C、Escと入力保全、繰り返し表示、狭い画面と監視継続の4項目を検証します。ログイン済みプロファイルを使わず、ページへの通信は合成HTMLで応答します。クリップボードの読み取り許可は合成試験の比較用だけです。本体にはクリップボードAPIを追加していません。

今回用意したPlaywrightは1.62.1。実行環境のソケット制限によりChromium起動前後の初期処理で停止したため、4項目は未実施です。Windows/Tampermonkey実機の代替試験でもありません。

ブラウザを起動できる隔離した開発環境で、必要に応じて次を実行します。

```sh
npm install --no-save --package-lock=false --ignore-scripts playwright@1.62.1
npx playwright install chromium
node verify-browser.cjs
```

既存Chromiumを使う場合は環境変数CRN_BROWSER_PATHに実在する実行ファイルの絶対パスを指定します。結果と確認画像は新しい一時ディレクトリへ保存されます。本配布には画面確認画像はありません。

## 根拠の区別

verification/verified-base/は1.5.3の旧不具合再現用です。candidate-1.5.6/evidence/内のDOM構造は以前採取したもので、本文と試験時刻は合成です。

今回の利用者報告はevidence/usage-diagnostic-v1.5.5-received-2026-11-15.txt。省略された原文をそのまま保存し、欠落部分を補っていません。

ファイルサイズとSHA-256はMANIFEST.json。版番号付きJS/TXTと検証対象JSは同一バイト列です。
