# 1.5.7の検証

ソースSHA-256: `509fb27aea6c1bca4a949519ddc2c00c204dd4469e6b6b4c802df548cc2b1420`。88,737バイト。Node.js 24.22.1、jsdom 30.1.1で構文検査と168/168件に合格。

```sh
npm ci --ignore-scripts --no-audit --no-fund
npm test
```

verify.cjsは新しい一時ディレクトリへverification/を展開し、113件、16件、19件、7件、13件を実行します。同梱の証拠を上書きしません。DOM、通知、時計、再読み込み、dialog APIは模擬です。

今回の結果はverification-results-2026-11-16/。最初は不変比較のテストハーネスがasync functionを見落として1件失敗し、ハーネス訂正後に全168件を再実行して合格しました。製品ソースは同一です。

## 実ブラウザ・実機

今回の実ブラウザ試験は未実施。前回1.5.6の隔離Chromiumはsocket() EPERMで起動できず、今回この制限を回避する試行はしていません。1.5.6の全文JSON受領は確認しましたが、1.5.7の追加観測と実際の回復通知はWindowsで確認が必要です。

verify-browser.cjsは前回から引き継いだ合成ページでの4項目用です。診断UI・コピー・Esc等の確認を補助します。1.5.7の非表示DOMや通知到達を検証するものではなく、今回の合格件数にも含めません。利用する場合はブラウザを起動できる隔離環境で、Playwright 1.62.1と対応Chromiumを用意してください。

## 保全

evidence/の提出JSONは元のバイト列を保持。verification/previous-candidate/は比較用1.5.6、verified-base/は旧回答検出比較用です。通常配布物は1.5.4を別途維持しています。これらを最新版と取り違えないでください。
