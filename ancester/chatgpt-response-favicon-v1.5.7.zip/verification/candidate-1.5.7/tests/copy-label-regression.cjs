'use strict';
// Reconstruct only the recorded ancestry and labels. Body text, timing and
// relationships between separate samples are synthetic, not a captured page.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { fixture, hidden, streaming } = require('./investigation-fixture.cjs');
const old = require('../../verified-base/ancester/tests/investigation-fixture.cjs');
const captures = JSON.parse(fs.readFileSync(__dirname + '/../evidence/captured-dom-shapes.json', 'utf8'));
const results = [];
const escape = value => String(value).replaceAll('&', '&amp;').replaceAll('"', '&quot;').replaceAll('<', '&lt;');

function shape(sample, text = 'Synthetic response') {
    let markup = '';
    const controls = sample.ancestry.findLastIndex(node => node.classHints.includes('turn-action-controls'));
    for (let i = 0; i < sample.ancestry.length; i++) {
        const n = sample.ancestry[i];
        assert.match(n.tag, /^(button|div|span|section|article)$/);
        let attrs = n.classHints.length ? ` class="${escape(n.classHints.join(' '))}"` : '';
        for (const [key, value] of [['role', n.semanticRole], ['data-message-author-role', n.authorRole], ['data-turn', n.dataTurn]]) {
            if (value && value !== '[other]') attrs += ` ${key}="${escape(value)}"`;
        }
        if (n.conversationTurnMarker) attrs += ' data-testid="conversation-turn-synthetic"';
        if (!i) attrs += ` aria-label="${escape(sample.label)}"`;
        const body = i === controls + 1 && sample.label === 'コピーする' ? `<div>${escape(text)}</div>` : '';
        markup = `<${n.tag}${attrs}>${body}${markup}</${n.tag}>`;
    }
    return markup;
}
const answerSample = c => c.diagnostics.actionCandidates.samples.find(s => s.label === 'コピーする');
const capturedMarkup = c => c.diagnostics.actionCandidates.samples.filter(s => s.hasLegacyActionContainer).map(s => shape(s)).join('');
async function insert(p, markup) {
    await p.evaluate(markup => document.getElementById('conversation').insertAdjacentHTML('beforeend', markup), markup);
    await p.clock.runFor(100);
}
async function begin(p) {
    await p.evaluate(() => document.querySelector('#work-editor, #prompt-textarea').dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true })));
    await p.clock.runFor(100);
}
async function inspect(p) {
    return p.evaluate(() => ({
        ...window.__chatgptResponseFaviconV2.inspect(),
        calls: window.testNotifications.length,
        icon: document.getElementById('original').getAttribute('href')
    }));
}
async function settle(p) { await p.clock.runFor(4000); return inspect(p); }
async function test(name, fn) {
    try {
        const evidence = await fn();
        results.push({ name, result: 'PASS', ...(evidence ? { evidence } : {}) });
        console.log('PASS', name);
    } catch (error) {
        results.push({ name, result: 'FAIL', error: error.stack });
        console.error('FAIL', name, error);
    }
}
function options(c) { return { empty: true, work: true, richLabel: c.reportedMode === 'Chat' ? 'Message ChatGPT' : 'Work モードで作成' }; }

(async () => {
    for (const c of captures) {
        await test(`${c.reportedMode}: recorded ancestry reproduces zero roots in 1.5.3 and recognizes the new label in candidate 1.5.6`, async () => {
            const observations = {};
            for (const [version, factory] of [['1.5.3', old.fixture], ['1.5.7', fixture]]) {
                const p = await factory(options(c));
                try {
                    await begin(p); await streaming(p, true); await insert(p, capturedMarkup(c));
                    await streaming(p, false); const d = await settle(p);
                    const expected = c.diagnostics.actionCandidates.samples.filter(s => s.label === 'コピーする').length;
                    assert.equal(d.assistantTurns, version === '1.5.3' ? 0 : expected);
                    assert.equal(d.latestAnswerHasCopy, version === '1.5.7');
                    assert.equal(d.waiting, version === '1.5.3');
                    assert.equal(d.calls, version === '1.5.3' ? 0 : 1);
                    observations[version] = { answerRoots: d.assistantTurns, waiting: d.waiting, desktopCalls: d.calls };
                } finally { await p.close(); }
            }
            return observations;
        });
        await test(`${c.reportedMode}: two completed responses notify once each and restore the icon on return`, async () => {
            const p = await fixture(options(c));
            try {
                const original = (await inspect(p)).icon;
                for (let cycle = 1; cycle <= 2; cycle++) {
                    await hidden(p, true); await begin(p); await streaming(p, true);
                    await insert(p, shape(answerSample(c), `Synthetic cycle ${cycle}`));
                    await streaming(p, false); let d = await settle(p);
                    assert.equal(d.notification, 'done'); assert.equal(d.calls, cycle); assert.notEqual(d.icon, original);
                    await p.clock.runFor(10000); assert.equal((await inspect(p)).calls, cycle);
                    await hidden(p, false); d = await inspect(p);
                    assert.equal(d.notification, 'none'); assert.equal(d.icon, original);
                }
            } finally { await p.close(); }
        });
        await test(`${c.reportedMode}: an instant response is detected without observing streaming`, async () => {
            const p = await fixture(options(c));
            try { await begin(p); await insert(p, shape(answerSample(c))); const d = await settle(p); assert.equal(d.calls, 1); assert.equal(d.waiting, false); }
            finally { await p.close(); }
        });
        await test(`${c.reportedMode}: loading recorded history does not notify`, async () => {
            const p = await fixture(options(c));
            try { await insert(p, capturedMarkup(c)); const d = await settle(p); assert.equal(d.calls, 0); assert.equal(d.waiting, false); }
            finally { await p.close(); }
        });
    }
    const c = captures[0];
    await test('User-message copy controls remain excluded for both Japanese labels', async () => {
        const p = await fixture(options(c));
        try {
            const user = c.diagnostics.actionCandidates.samples.find(s => s.label === 'メッセージをコピーする');
            await begin(p); await insert(p, shape(user) + shape({ ...user, label: 'コピーする' }));
            const d = await settle(p); assert.equal(d.assistantTurns, 0); assert.equal(d.calls, 0); assert.equal(d.waiting, true);
        } finally { await p.close(); }
    });
    await test('Code-copy controls outside turn actions cannot complete an instant response', async () => {
        const p = await fixture({ empty: true });
        try {
            await begin(p);
            await insert(p, '<div data-message-author-role="assistant"><pre><code>Synthetic code</code></pre><button aria-label="コピーする">Copy code</button></div>');
            const d = await settle(p); assert.equal(d.assistantTurns, 1); assert.equal(d.latestAnswerHasCopy, false); assert.equal(d.waiting, true); assert.equal(d.calls, 0);
        } finally { await p.close(); }
    });
    await test('Unrelated copy buttons do not become response roots', async () => {
        const p = await fixture(options(c));
        try {
            await begin(p); await insert(p, '<div role="dialog"><button aria-label="コピーする">Copy</button></div>');
            const d = await settle(p); assert.equal(d.assistantTurns, 0); assert.equal(d.calls, 0);
        } finally { await p.close(); }
    });
    for (const condition of ['hidden', 'disabled']) {
        await test(`${condition} copy action does not complete an instant response until available`, async () => {
            const p = await fixture(options(c));
            try {
                await begin(p); await insert(p, shape(answerSample(c)).replace('aria-label="コピーする"', `aria-label="コピーする" ${condition}`));
                let d = await settle(p); assert.equal(d.calls, 0); assert.equal(d.waiting, true);
                await p.evaluate(condition => document.querySelector('#conversation button').removeAttribute(condition), condition);
                d = await settle(p); assert.equal(d.calls, 1); assert.equal(d.waiting, false);
            } finally { await p.close(); }
        });
    }
    await test('A visible stop control prevents early completion even when copy is present', async () => {
        const p = await fixture(options(c));
        try {
            await begin(p); await streaming(p, true); await insert(p, shape(answerSample(c)));
            let d = await settle(p); assert.equal(d.calls, 0); assert.equal(d.waiting, true);
            await streaming(p, false); d = await settle(p); assert.equal(d.calls, 1);
        } finally { await p.close(); }
    });
    await test('Manual stop still cancels completion notification', async () => {
        const p = await fixture(options(c));
        try {
            await begin(p); await streaming(p, true); await insert(p, shape(answerSample(c)));
            await p.evaluate(() => document.querySelector('[data-testid="stop-button"]').click());
            await streaming(p, false); const d = await settle(p); assert.equal(d.calls, 0);
        } finally { await p.close(); }
    });
    await test('Notification remains suppressed while the conversation tab is visible', async () => {
        const p = await fixture(options(c));
        try {
            await hidden(p, false); await begin(p); await insert(p, shape(answerSample(c)));
            const d = await settle(p); assert.equal(d.waiting, false); assert.equal(d.calls, 0); assert.equal(d.notification, 'none');
        } finally { await p.close(); }
    });
    const source = fs.readFileSync(__dirname + '/../chatgpt-response-favicon.user.js');
    const output = { sourceSHA256: crypto.createHash('sha256').update(source).digest('hex'), runtime: process.version, jsdom: require('jsdom/package.json').version,
        scope: 'Recorded DOM ancestry and labels; synthetic body, timing and relative placement; notification API mocked; not a Windows physical test',
        passed: results.filter(r => r.result === 'PASS').length, total: results.length, results };
    fs.writeFileSync(__dirname + '/copy-label-results.json', JSON.stringify(output, null, 2) + '\n', { flag: 'wx' });
    console.log(`${output.passed}/${output.total} passed`);
    process.exitCode = output.passed === output.total ? 0 : 1;
})().catch(error => { console.error(error); process.exitCode = 1; });
