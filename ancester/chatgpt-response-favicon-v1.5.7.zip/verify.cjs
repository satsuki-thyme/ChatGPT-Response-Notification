'use strict';
// Delivered evidence remains unchanged; each run creates a new temporary tree.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawnSync } = require('node:child_process');
const target = fs.mkdtempSync(path.join(os.tmpdir(), 'crn-v1.5.7-'));
const nodePath = path.dirname(path.dirname(require.resolve('jsdom/package.json')));
fs.cpSync(path.join(__dirname, 'verification'), target, {
    recursive: true, filter: source => !path.basename(source).endsWith('-results.json')
});
const candidate = path.join(target, 'candidate-1.5.7');
console.log('Verification directory:', target);
for (const args of [
    ['--check', 'chatgpt-response-favicon.user.js'],
    ['tests/test-favicon-dom.cjs'],
    ['tests/copy-label-regression.cjs'],
    ['tests/usage-trace-regression.cjs'],
    ['tests/diagnostic-dialog-regression.cjs'],
    ['tests/usage-reader-probe-regression.cjs']
]) {
    const result = spawnSync(process.execPath, args, { cwd: candidate, env: { ...process.env, NODE_PATH: nodePath }, stdio: 'inherit' });
    if (result.error) throw result.error;
    if (result.status !== 0) process.exit(result.status || 1);
}
