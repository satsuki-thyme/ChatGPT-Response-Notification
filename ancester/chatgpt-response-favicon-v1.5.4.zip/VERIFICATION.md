# 自動検証の再実行

ZIPを展開したディレクトリでNode.js 24以上を使い、次を実行する。

```sh
npm install --ignore-scripts --no-audit --no-fund
npm test
```

固定依存はjsdom 30.1.1。`verify.cjs`が一時ディレクトリを新規作成し、配布物内の結果を上書きせず試験する。出力先は実行時に表示する。

期待結果は既存113/113、追加16/16。元の1.5.3を使う2件は、不具合の再現が期待結果。1.5.4側では回答検出・完了通知に進むことを確認する。

`verification/fix-1.5.4/evidence/captured-dom-shapes.json`は採取内容をChat・Workのラベル付きJSONへ整理したもの。会話本文は含まない。試験に使う本文・タイミング・サンプル間配置・入力欄ラベルは合成。実サイトやWindowsの通知APIを操作する試験ではない。

`verification/fix-1.5.4/tests/favicon-test-results.json`と`copy-label-results.json`は作成時の結果。`verification/verified-base`は比較用1.5.3本体とfixture。古い本体を新しい本体と同時にインストールしない。
