'use strict';
// Run in a new temporary directory, preserving all delivered evidence files.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawnSync } = require('node:child_process');
const target = fs.mkdtempSync(path.join(os.tmpdir(), 'crn-v1.5.4-'));
const nodePath = path.dirname(path.dirname(require.resolve('jsdom/package.json')));
fs.cpSync(path.join(__dirname, 'verification'), target, {
    recursive: true,
    filter: source => !['favicon-test-results.json', 'copy-label-results.json'].includes(path.basename(source))
});
const candidate = path.join(target, 'fix-1.5.4');
console.log('Verification directory:', target);
for (const args of [
    ['--check', 'chatgpt-response-favicon.user.js'],
    ['tests/test-favicon-dom.cjs'],
    ['tests/copy-label-regression.cjs']
]) {
    const result = spawnSync(process.execPath, args, { cwd: candidate, env: { ...process.env, NODE_PATH: nodePath }, stdio: 'inherit' });
    if (result.error) throw result.error;
    if (result.status !== 0) process.exit(result.status || 1);
}
