# 1.5.8検証

完成ソースSHA-256: `7b60fa3f288ba0ef960b67951d98cce0f212a340e73ebc7fe1d73419c0f1bffc`。Node.js 24.22.1 / jsdom 30.1.1。構文検査と185/185件合格。

```sh
npm ci --ignore-scripts --no-audit --no-fund
npm test
```

verify.cjsは新しい一時ディレクトリへ展開し、113＋16＋19＋7＋13＋17件を実行する。同梱の証拠を上書きしない。既存の入力中試験1件は本文ありの条件へ具体化。追加17件で1.5.7の空欄停止を再現し、1.5.8と比較する。通知・利用枠処理等10関数の不変性も比較する。更新保護は意図的な変更なので比較対象から除外し、挙動を検証する。

verification-results-2026-11-18/が完成コードの実行結果。sourceSHA256を持つ結果と候補コードの一致を確認している。evidence/は受領JSONの元バイト列。

DOM・時計・通知API・再読み込み・IMEイベントは模擬。実機の通知表示と同一視しない。今回の実ブラウザ試験は未実施。前回のsocket() EPERM制限を回避する試行はしていない。verify-browser.cjsは引き継いだ診断UIの合成4項目用で、今回の185件やIME・連続更新の実機受入には含めない。

verification/baseline-1.5.7/とprevious-candidate/、verified-base/は比較専用。実機にはルートの1.5.8版番号付きJSまたはTXTを使う。通常の版番号なしソースとpackage.jsonはDropbox側で1.5.4を維持している。
