'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const { fixture, hidden } = require('./investigation-fixture.cjs');
const KEY = 'chatgpt-response-favicon:usage-trace:v1';
const BASE = 1790856000000;
const card = (n = 30) => `<main><section><h2>5-hour limit</h2><p class="metric">${n}% remaining</p></section></main>`;
const usage = (html = card(), extra = {}) => fixture({ pathname: '/settings/usage', usageHTML: html, ...extra });
const inspect = p => p.evaluate(() => ({ ...window.__chatgptResponseFaviconV2.inspectUsage(),
    reloads: window.testReloads, notifications: window.testNotifications.length }));
const results = [];
async function test(name, fn) {
    try { await fn(); results.push({ name, result: 'PASS' }); console.log('PASS', name); }
    catch (error) { results.push({ name, result: 'FAIL', error: error.stack }); console.error('FAIL', name, error); }
}
async function using(promise, fn) { const p = await promise; try { await fn(p); } finally { await p.close(); } }

(async () => {
    await test('Hidden reload followed by missing labels and later visible labels remains distinguishable', async () => {
        let session;
        await using(usage(), async p => {
            await p.clock.runFor(65000); assert.equal((await inspect(p)).reloads, 1);
            session = await p.evaluate(() => Object.fromEntries(Object.entries(sessionStorage)));
        });
        await using(usage('<main aria-busy="true"></main>', { session, clockStart: 70000 }), async p => {
            await p.clock.observed(220000); let d = await inspect(p);
            assert.equal(d.reloads, 0); assert.equal(d.readerProbe.labels.known, 0);
            assert.equal(d.readerProbe.scopeBusy, true);
            assert.equal(d.usageTrace.lastHiddenObservation.reloadBlockedBy, 'unrecognized');
            assert.equal(d.usageTrace.lastHiddenObservation.readerProbe.labels.known, 0);
            assert.ok(d.usageTrace.events.some(e => e.event === 'reload-request' && e.scriptVersion === '1.5.8'));
            await hidden(p, false); await p.evaluate(html => document.body.innerHTML = html, card(91));
            await p.clock.runFor(1500); d = await inspect(p);
            assert.equal(d.status, 'recognized'); assert.equal(d.readerProbe.labels.eligible, 1);
            assert.equal(d.usageTrace.lastHiddenObservation.readerProbe.labels.known, 0);
            assert.equal(d.notifications, 0);
        });
    });
    await test('Existing labels with no layout boxes are distinguished from absent labels without using hidden values', () => using(usage(card(100)), async p => {
        await p.evaluate(() => document.querySelector('section').style.display = 'none');
        await p.clock.runFor(65000); const d = await inspect(p);
        assert.equal(d.status, 'unknown'); assert.equal(d.readerProbe.labels.known, 1);
        assert.equal(d.readerProbe.labels.notVisible, 1); assert.equal(d.readerProbe.labels.noBox, 1);
        assert.equal(d.readerProbe.labels.eligible, 0); assert.equal(d.reloads, 0); assert.equal(d.notifications, 0);
    }));
    await test('ARIA/hidden exclusion is distinguished from style visibility and never creates recovery', () => using(usage(card(100)), async p => {
        await p.evaluate(() => document.querySelector('section').setAttribute('aria-hidden', 'true'));
        await p.clock.runFor(3500); const d = await inspect(p);
        assert.equal(d.status, 'unknown'); assert.equal(d.readerProbe.labels.excluded, 1);
        assert.equal(d.readerProbe.labels.notVisible, 0); assert.equal(d.notifications, 0);
    }));
    await test('Recognized labels with unsupported metrics remain unknown instead of implying recovery', () => using(usage('<main><h2>5-hour limit</h2><p>Reset 15:00</p></main>'), async p => {
        await p.clock.runFor(3500); const d = await inspect(p);
        assert.equal(d.readerProbe.labels.eligible, 1); assert.equal(d.status, 'unknown');
        assert.deepEqual(d.readerProbe.keys, ['hours-5']); assert.equal(d.notifications, 0);
    }));
    await test('Probe scope follows the selected dialog instead of treating unrelated main labels as readable', () => using(usage(card() + '<div role="dialog"><p>PRIVATE ACCOUNT INFO</p></div>'), async p => {
        await p.clock.runFor(3500); const d = await inspect(p);
        assert.equal(d.readerProbe.scope, 'dialog'); assert.equal(d.readerProbe.labels.known, 0);
        assert.equal(d.status, 'unknown'); assert.ok(!JSON.stringify(d.usageTrace).includes('PRIVATE'));
    }));
    await test('Empty focused input is identified but still protects against reload in a hidden unfocused document', () => using(usage(card() + '<input type="search" id="private-id" placeholder="PRIVATE PLACEHOLDER">'), async p => {
        await p.evaluate(() => document.querySelector('input').focus()); await p.clock.runFor(65000);
        const d = await inspect(p); const f = d.usageTrace.lastHiddenObservation.readerProbe.focus;
        assert.equal(d.reloads, 0); assert.equal(d.readerProbe.documentFocus, false);
        assert.equal(d.usageTrace.lastHiddenObservation.reloadBlockedBy, 'input-focus');
        assert.equal(f.tag, 'input'); assert.equal(f.type, 'search'); assert.equal(f.hasContent, false);
        assert.equal(f.guardMatch, true); assert.ok(!JSON.stringify(d).includes('private-id'));
        assert.ok(!JSON.stringify(d).includes('PRIVATE PLACEHOLDER'));
    }));
    await test('Focused draft content is reduced to a boolean and preserved unchanged', () => using(usage(card() + '<textarea>PRIVATE UNSENT DRAFT</textarea>'), async p => {
        await p.evaluate(() => document.querySelector('textarea').focus()); await p.clock.runFor(65000);
        const d = await inspect(p); assert.equal(d.reloads, 0); assert.equal(d.readerProbe.focus.hasContent, true);
        assert.ok(!JSON.stringify(d).includes('PRIVATE UNSENT DRAFT'));
        assert.equal(await p.evaluate(() => document.querySelector('textarea').value), 'PRIVATE UNSENT DRAFT');
    }));
    await test('Password and select contents are not inspected by the probe', async () => {
        for (const html of ['<input type="password" value="PRIVATE PASSWORD">', '<select><option>PRIVATE SELECTION</option></select>']) {
            await using(usage(card() + html), async p => {
                await p.evaluate(() => document.querySelector('input,select').focus());
                const d = await inspect(p); assert.equal(d.readerProbe.focus.hasContent, null);
                assert.ok(!JSON.stringify(d).includes('PRIVATE')); assert.equal(d.readerProbe.focus.guardMatch, true);
            });
        }
    });
    await test('Legacy history survives and malicious probe fields are removed on readback', () => {
        const event = { event: 'sample', at: BASE - 1000, visibility: 'hidden',
            readerProbe: { version: 1, status: 'sampled', scope: 'PRIVATE URL', keys: ['hours-5', 'PRIVATE KEY'],
                inspected: 999999, labels: { known: -1, eligible: 'PRIVATE DATA' },
                focus: { tag: 'PRIVATE TAG', type: 'PRIVATE TYPE', value: 'PRIVATE PASSWORD' }, html: 'PRIVATE HTML' } };
        return using(usage(card(), { session: { [KEY]: JSON.stringify({ version: 1, updatedAt: BASE - 1000,
            events: [{ event: 'sample', at: BASE - 2000 }, event], lastHidden: event }) } }), async p => {
            const d = await inspect(p); assert.equal(d.usageTrace.readStatus, 'loaded');
            assert.equal(d.usageTrace.events[0].scriptVersion, null); assert.equal(d.usageTrace.events[0].readerProbe, null);
            assert.ok(!JSON.stringify(d.usageTrace).includes('PRIVATE'));
            assert.equal(d.usageTrace.events[1].readerProbe.labels.known, null);
            assert.equal(d.usageTrace.events[1].readerProbe.inspected, null);
        });
    });
    await test('Probe failure cannot prevent quota recovery or ordinary hidden reload', () => using(usage(card(0)), async p => {
        await p.clock.runFor(3500);
        await p.evaluate(() => {
            const create = document.createTreeWalker.bind(document);
            document.createTreeWalker = (root, what, ...args) => {
                if (what === NodeFilter.SHOW_ELEMENT) throw Error('PRIVATE PROBE ERROR');
                return create(root, what, ...args);
            };
            document.querySelector('.metric').textContent = '60% remaining';
        });
        await p.clock.runFor(65000); const d = await inspect(p);
        assert.equal(d.readerProbe.status, 'failed'); assert.equal(d.notifications, 1);
        assert.equal(d.reloads, 1); assert.equal(d.savedState, true); assert.equal(d.usageTrace.writeStatus, 'saved');
        assert.ok(!JSON.stringify(d).includes('PRIVATE PROBE ERROR'));
    }));
    await test('Added DOM scan is bounded and marked incomplete when the inspection cap is reached', () => using(usage('<main>' + '<i></i>'.repeat(2005) + '<h2>5-hour limit</h2><p>30% remaining</p></main>'), async p => {
        const d = await inspect(p); assert.equal(d.readerProbe.inspected, 2000);
        assert.equal(d.readerProbe.truncated, true); assert.equal(d.readerProbe.labels.known, 0);
        assert.equal(d.status, 'recognized'); // Probe truncation never changes the actual reader.
    }));
    await test('Unchanged samples keep the existing trace cadence and remain below its storage limit', () => using(usage(), async p => {
        await p.evaluate(() => {
            window.probeScans = 0; const create = document.createTreeWalker.bind(document);
            document.createTreeWalker = (root, what, ...args) => {
                if (what === NodeFilter.SHOW_ELEMENT) window.probeScans++;
                return create(root, what, ...args);
            };
        });
        await p.clock.runFor(14500);
        assert.equal(await p.evaluate(() => window.probeScans), 0);
        await p.clock.runFor(1000); assert.equal(await p.evaluate(() => window.probeScans), 1);
        await p.evaluate(() => { for (let i = 0; i < 80; i++) window.dispatchEvent(new Event(i % 2 ? 'online' : 'offline')); });
        const d = await inspect(p); assert.equal(d.usageTrace.events.length, 48);
        assert.ok((await p.evaluate(key => sessionStorage.getItem(key).length, KEY)) < 131072);
        assert.ok(d.usageTrace.events.every(e => e.scriptVersion === '1.5.8'));
    }));
    await test('Notification and quota detection functions are byte-identical to 1.5.7; reload guard is tested separately', () => {
        const current = fs.readFileSync(__dirname + '/../chatgpt-response-favicon.user.js', 'utf8');
        const previous = fs.readFileSync(__dirname + '/../../previous-candidate/chatgpt-response-favicon-v1.5.7.user.js', 'utf8');
        const part = (source, name) => source.match(new RegExp(`    (?:async )?function ${name}\\([\\s\\S]*?(?=\\n    (?:async )?function |$)`))?.[0];
        for (const name of ['usageText', 'usageLabel', 'usageMetric', 'usageSnapshot',
            'checkUsageMonitor', 'readUsageState', 'saveUsageState', 'requestRecovery', 'desktopNotify', 'isVisible']) {
            assert.ok(part(current, name)); assert.equal(part(current, name), part(previous, name), name);
        }
        assert.deepEqual(current.match(/^\/\/ @(?:name|namespace|match|grant).*$/gm), previous.match(/^\/\/ @(?:name|namespace|match|grant).*$/gm));
    });
    fs.writeFileSync(__dirname + '/usage-reader-probe-results.json', JSON.stringify({
        environment: 'Node.js/jsdom; synthetic DOM, clock, reload and notification APIs', results,
        total: results.length, passed: results.filter(r => r.result === 'PASS').length,
        failed: results.filter(r => r.result === 'FAIL').length
    }, null, 2) + '\n');
    if (results.some(r => r.result === 'FAIL')) process.exitCode = 1;
})();
