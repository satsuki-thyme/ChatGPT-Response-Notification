'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { fixture, hidden } = require('./investigation-fixture.cjs');
const { fixture: oldFixture } = require('../../baseline-1.5.7/tests/investigation-fixture.cjs');
const source = fs.readFileSync(__dirname + '/../chatgpt-response-favicon.user.js', 'utf8');
const card = n => `<main><section><h2>5-hour limit</h2><p class="metric">${n}% remaining</p></section></main>`;
const html = (n = 70) => card(n) + '<input id="outside" type="text">';
const usage = (options = {}) => fixture({ pathname: '/settings/usage', usageHTML: html(), ...options });
const focus = p => p.evaluate(() => document.querySelector('#outside').focus());
const inspect = p => p.evaluate(() => ({ ...window.__chatgptResponseFaviconV2.inspectUsage(),
    reloads: window.testReloads, notifications: window.testNotifications.length, windowFocuses: window.testFocus }));
const results = [];
async function using(promise, fn) { const p = await promise; try { await fn(p); } finally { await p.close(); } }
async function test(name, fn) {
    try { await fn(); results.push({ name, result: 'PASS' }); console.log('PASS', name); }
    catch (error) { results.push({ name, result: 'FAIL', error: error.stack }); console.error('FAIL', name, error); }
}

(async () => {
    await test('1.5.7 reproduces the reported empty outside text focus stall', () => using(oldFixture({
        pathname: '/settings/usage', usageHTML: html()
    }), async p => {
        await focus(p); await p.clock.observed(165000); const d = await inspect(p);
        assert.equal(d.reloads, 0); assert.equal(d.usageTrace.lastHiddenObservation.reloadBlockedBy, 'input-focus');
        assert.equal(d.readerProbe.documentFocus, false); assert.equal(d.readerProbe.focus.hasContent, false);
        assert.equal(d.readerProbe.focus.inScope, false);
    }));
    await test('1.5.8 permits consecutive reloads for the observed empty stale focus without blurring or focusing', () => using(usage(), async p => {
        await focus(p); await p.evaluate(() => { window.blurs = 0; document.querySelector('#outside').addEventListener('blur', () => window.blurs++); });
        await p.clock.observed(125000); const d = await inspect(p);
        assert.equal(d.version, '1.5.8'); assert.equal(d.reloads, 2); assert.equal(d.notifications, 0);
        assert.equal(d.usageTrace.lastHiddenObservation.reloadBlockedBy, null); assert.equal(d.windowFocuses, 0);
        assert.equal(d.readerProbe.focus.hasRawContent, false);
        assert.equal(await p.evaluate(() => window.blurs), 0);
        assert.equal(await p.evaluate(() => document.activeElement.id), 'outside');
    }));
    await test('Reloaded hidden documents keep the fix and announce a saved blocked-to-available transition once', async () => {
        let session;
        await using(usage({ usageHTML: html(0) }), async p => {
            await focus(p); await p.clock.runFor(3500); await p.clock.observed(61000);
            assert.equal((await inspect(p)).reloads, 1);
            session = await p.evaluate(() => Object.fromEntries(Object.entries(sessionStorage)));
        });
        await using(usage({ usageHTML: html(45), session, clockStart: 70000 }), async p => {
            await focus(p); await p.clock.runFor(4000); await p.clock.observed(61000); const d = await inspect(p);
            assert.equal(d.notifications, 1); assert.equal(d.reloads, 1);
            assert.ok(d.usageTrace.events.some(e => e.event === 'recovery-result' && e.visibility === 'hidden' && e.recoveryCoordination === 'requested'));
        });
    });
    await test('Visible usage remains protected even with an empty outside text input', () => using(usage(), async p => {
        await focus(p); await hidden(p, false); await p.clock.observed(65000);
        const d = await inspect(p); assert.equal(d.reloads, 0); assert.equal(d.reloadBlockedBy, 'visible');
    }));
    await test('A document reporting focus is protected even when visibility is hidden', () => using(usage(), async p => {
        await focus(p); await p.evaluate(() => Object.defineProperty(document, 'hasFocus', { configurable: true, value: () => true }));
        await p.clock.observed(65000); const d = await inspect(p);
        assert.equal(d.reloads, 0); assert.equal(d.reloadBlockedBy, 'input-focus');
    }));
    await test('Focused controls inside the selected usage scope are not exempted', () => using(usage(), async p => {
        await p.evaluate(() => document.querySelector('main').append(document.querySelector('#outside')));
        await focus(p); await p.clock.observed(65000); const d = await inspect(p);
        assert.equal(d.readerProbe.focus.inScope, true); assert.equal(d.reloads, 0);
    }));
    await test('Conversation routes and hash-only settings retain the original protections', async () => {
        for (const [pathname, reason] of [['/c/private#settings/Usage', 'conversation-route'], ['/work/private#settings/Usage', 'conversation-route'], ['/#settings/Usage', 'input-focus']]) {
            await using(usage({ pathname }), async p => {
                await focus(p); await p.clock.observed(65000); const d = await inspect(p);
                assert.equal(d.reloads, 0); assert.equal(d.reloadBlockedBy, reason);
            });
        }
    });
    await test('Nonempty and whitespace-only focused text stay intact and prevent reload', async () => {
        for (const value of ['PRIVATE DRAFT', '   ', '\u3000']) {
            await using(usage(), async p => {
                await p.evaluate(v => document.querySelector('#outside').value = v, value); await focus(p);
                await p.clock.observed(65000); const d = await inspect(p);
                assert.equal(d.reloads, 0); assert.equal(d.reloadBlockedBy, 'input-focus');
                assert.equal(d.readerProbe.focus.hasRawContent, true);
                assert.equal(d.readerProbe.focus.hasContent, value.trim().length > 0);
                assert.equal(await p.evaluate(() => document.querySelector('#outside').value), value);
                assert.ok(!JSON.stringify(d.usageTrace).includes('PRIVATE DRAFT'));
            });
        }
    });
    await test('An empty focused input cannot override another draft, including whitespace', async () => {
        for (const draft of ['<textarea>PRIVATE DRAFT</textarea>', '<textarea> </textarea>', '<div contenteditable="true">PRIVATE RICH</div>', '<div contenteditable="true"> </div>']) {
            await using(usage({ usageHTML: html() + draft }), async p => {
                await focus(p); const before = await p.evaluate(() => document.body.innerHTML);
                await p.clock.observed(65000); const d = await inspect(p);
                assert.equal(d.reloads, 0); assert.equal(d.reloadBlockedBy, 'unsent-input');
                assert.equal(await p.evaluate(() => document.body.innerHTML), before);
                assert.ok(!JSON.stringify(d.usageTrace).includes('PRIVATE'));
            });
        }
    });
    await test('Textarea, select, password, search and number focus are not widened into the exception', async () => {
        for (const control of ['<textarea id="outside"></textarea>', '<select id="outside"><option></option></select>', '<input id="outside" type="password">', '<input id="outside" type="search">', '<input id="outside" type="number">']) {
            await using(usage({ usageHTML: card(70) + control }), async p => {
                await focus(p); await p.clock.observed(65000); const d = await inspect(p);
                assert.equal(d.reloads, 0); assert.equal(d.reloadBlockedBy, 'input-focus');
            });
        }
    });
    await test('An empty composition blocks reload until a matching end even after focus moves', () => using(usage(), async p => {
        await focus(p); await p.evaluate(() => {
            const input = document.querySelector('#outside');
            input.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true, data: 'PRIVATE IME' }));
            input.blur();
        });
        await p.clock.observed(65000); let d = await inspect(p);
        assert.equal(d.reloads, 0); assert.equal(d.inputComposition, true); assert.equal(d.reloadBlockedBy, 'input-composition');
        assert.ok(d.usageTrace.events.some(e => e.inputComposition === true)); assert.ok(!JSON.stringify(d).includes('PRIVATE IME'));
        await p.evaluate(() => document.querySelector('#outside').dispatchEvent(new CompositionEvent('compositionend', { bubbles: true })));
        await p.clock.runFor(1500); d = await inspect(p); assert.equal(d.reloads, 1); assert.equal(d.inputComposition, false);
    }));
    await test('Composing beforeinput is recognized and final committed text remains protected', () => using(usage(), async p => {
        await focus(p); await p.evaluate(() => document.querySelector('#outside').dispatchEvent(new InputEvent('beforeinput', { bubbles: true, isComposing: true, data: 'PRIVATE COMPOSITION' })));
        await p.clock.observed(65000); assert.equal((await inspect(p)).reloads, 0);
        await p.evaluate(() => {
            const input = document.querySelector('#outside'); input.value = 'PRIVATE COMMITTED';
            input.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true }));
        });
        await p.clock.runFor(1500); const d = await inspect(p);
        assert.equal(d.inputComposition, false); assert.equal(d.reloads, 0); assert.equal(d.reloadBlockedBy, 'input-focus');
        assert.ok(!JSON.stringify(d).includes('PRIVATE'));
    }));
    await test('Compositionend from another element does not clear a pending composition', () => using(usage({ usageHTML: html() + '<input id="second">' }), async p => {
        await focus(p); await p.evaluate(() => {
            document.querySelector('#outside').dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true }));
            document.querySelector('#second').dispatchEvent(new CompositionEvent('compositionend', { bubbles: true }));
        });
        await p.clock.observed(65000); const d = await inspect(p);
        assert.equal(d.reloads, 0); assert.equal(d.inputComposition, true);
    }));
    await test('A removed composition target cannot permanently block the replacement empty page', () => using(usage(), async p => {
        await focus(p); await p.evaluate(() => {
            const input = document.querySelector('#outside');
            input.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true })); input.remove();
            const next = document.createElement('input'); next.id = 'outside'; document.body.append(next); next.focus();
        });
        await p.clock.observed(65000); const d = await inspect(p);
        assert.equal(d.inputComposition, false); assert.equal(d.reloads, 1);
    }));
    await test('Unrecognized usage after reload is still protected; hidden stale data is not accepted', () => using(usage({ usageHTML: '<main><div hidden><h2>5-hour limit</h2><p>70% remaining</p></div></main><input id="outside">' }), async p => {
        await focus(p); await p.clock.observed(65000); const d = await inspect(p);
        assert.equal(d.status, 'unknown'); assert.equal(d.reloadBlockedBy, 'unrecognized'); assert.equal(d.reloads, 0); assert.equal(d.notifications, 0);
    }));
    await test('Other reload guards still win when the empty-focus exception could apply', async () => {
        for (const mode of ['offline', 'disabled', 'notification', 'storage', 'generating']) {
            await using(usage({ ...(mode === 'disabled' ? { preferences: { 'crf:usageReload': false } } : {}),
                ...(mode === 'notification' ? { desktopAvailable: false } : {}) }), async p => {
                await focus(p); await p.evaluate(m => {
                    if (m === 'offline') Object.defineProperty(navigator, 'onLine', { configurable: true, value: false });
                    if (m === 'storage') { const write = Storage.prototype.setItem; Storage.prototype.setItem = function(key, value) {
                        if (key === 'chatgpt-response-favicon:usage:v1') throw Error('unavailable'); return write.call(this, key, value);
                    }; }
                    if (m === 'generating') { const b = document.createElement('button'); b.setAttribute('data-testid', 'stop-button'); document.body.append(b); }
                }, mode);
                await p.clock.observed(65000); const d = await inspect(p); assert.equal(d.reloads, 0, mode);
            });
        }
    });
    await test('Text arriving immediately before the deadline is preserved', () => using(usage({ usageHTML: html() + '<textarea></textarea>' }), async p => {
        await focus(p); await p.clock.observed(59000);
        await p.evaluate(() => document.querySelector('textarea').value = 'PRIVATE LAST MOMENT');
        await p.clock.runFor(2000); const d = await inspect(p);
        assert.equal(d.reloads, 0); assert.equal(d.reloadBlockedBy, 'unsent-input');
        assert.equal(await p.evaluate(() => document.querySelector('textarea').value), 'PRIVATE LAST MOMENT');
    }));
    fs.writeFileSync(__dirname + '/usage-focus-fix-results.json', JSON.stringify({
        sourceSHA256: crypto.createHash('sha256').update(source).digest('hex'), runtime: process.version,
        environment: 'Synthetic DOM, clock, reload, notification and IME events; not Windows acceptance',
        total: results.length, passed: results.filter(r => r.result === 'PASS').length, results
    }, null, 2) + '\n');
    if (results.some(r => r.result === 'FAIL')) process.exitCode = 1;
})();
