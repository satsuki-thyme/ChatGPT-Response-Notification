'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { fixture, hidden } = require('./investigation-fixture.cjs');
const source = fs.readFileSync(__dirname + '/../chatgpt-response-favicon.user.js', 'utf8');
const html = '<main><section><h2>5-hour limit</h2><p>54% remaining</p></section><section><h2>Weekly limit</h2><p>2% remaining</p></section></main>';
const usage = async suffix => {
    const p = await fixture({ pathname: '/settings/usage', usageHTML: html + (suffix || '') });
    await p.evaluate(() => { console.info = () => {}; });
    return p;
};
const open = p => p.evaluate(() => document.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyU', altKey: true, shiftKey: true, bubbles: true })));
const close = p => p.evaluate(() => document.getElementById('chatgpt-response-favicon-diagnostics').shadowRoot.querySelector('button:last-child').click());
const results = [];
async function test(name, fn) {
    try { await fn(); results.push({ name, result: 'PASS' }); console.log('PASS', name); }
    catch (error) { results.push({ name, result: 'FAIL', error: error.stack }); console.error('FAIL', name, error); }
}
async function using(promise, fn) { const p = await promise; try { await fn(p); } finally { await p.close(); } }

(async () => {
    await test('Long diagnostic JSON is preserved verbatim and fully selected without prompt', () => using(usage(), async p => {
        await p.evaluate(() => {
            window.testPromptCalls = 0; window.prompt = () => { window.testPromptCalls++; };
            for (let i = 0; i < 60; i++) window.dispatchEvent(new Event(i % 2 ? 'online' : 'offline'));
            window.expectedDiagnostic = JSON.stringify(window.__chatgptResponseFaviconV2.inspectUsage(), null, 2);
        });
        await open(p);
        const d = await p.evaluate(() => {
            const field = document.getElementById('chatgpt-response-favicon-diagnostics').shadowRoot.querySelector('textarea');
            return { value: field.value, expected: window.expectedDiagnostic, readOnly: field.readOnly,
                selectionStart: field.selectionStart, selectionEnd: field.selectionEnd, prompts: window.testPromptCalls };
        });
        assert.ok(d.value.length > 2000); assert.equal(d.value, d.expected); assert.equal(d.readOnly, true);
        assert.equal(d.selectionStart, 0); assert.equal(d.selectionEnd, d.value.length); assert.equal(d.prompts, 0);
        assert.equal(JSON.parse(d.value).usageTrace.events.length, 48);
    }));
    await test('Selection can be restored and repeated opening leaves one dialog', () => using(usage(), async p => {
        await open(p); await open(p);
        const result = await p.evaluate(() => {
            const root = document.getElementById('chatgpt-response-favicon-diagnostics').shadowRoot;
            const field = root.querySelector('textarea'); field.setSelectionRange(4, 8); root.querySelector('button').click();
            return { count: document.querySelectorAll('#chatgpt-response-favicon-diagnostics').length,
                start: field.selectionStart, end: field.selectionEnd, length: field.value.length };
        });
        assert.equal(result.count, 1); assert.equal(result.start, 0); assert.equal(result.end, result.length);
        await close(p); assert.equal(await p.evaluate(() => !!document.getElementById('chatgpt-response-favicon-diagnostics')), false);
    }));
    await test('Diagnostic text is excluded from usage parsing and unsent-input protection', () => using(usage(), async p => {
        await open(p); await p.clock.runFor(65000);
        const d = await p.evaluate(() => ({ ...window.__chatgptResponseFaviconV2.inspectUsage(), reloads: window.testReloads }));
        assert.equal(d.status, 'recognized'); assert.equal(d.rows.length, 2); assert.equal(d.reloadBlockedBy, null);
        assert.equal(d.reloads, 1);
    }));
    await test('Real draft text remains protected while diagnostics are open', () => using(usage('<textarea id="draft">UNSENT DRAFT</textarea>'), async p => {
        await open(p); await p.clock.runFor(65000);
        const d = await p.evaluate(() => ({ block: window.__chatgptResponseFaviconV2.inspectUsage().reloadBlockedBy,
            reloads: window.testReloads, draft: document.getElementById('draft').value }));
        assert.equal(d.block, 'unsent-input'); assert.equal(d.reloads, 0); assert.equal(d.draft, 'UNSENT DRAFT');
    }));
    await test('Closing restores focus to the original connected input without changing it', () => using(usage('<textarea id="draft">UNCHANGED</textarea>'), async p => {
        await hidden(p, false); await p.evaluate(() => document.getElementById('draft').focus());
        await open(p); await close(p);
        const d = await p.evaluate(() => ({ active: document.activeElement.id, value: document.getElementById('draft').value }));
        assert.deepEqual(d, { active: 'draft', value: 'UNCHANGED' });
    }));
    await test('Reinjection and disposal remove diagnostic UI and prior handlers', () => using(usage(), async p => {
        await open(p); await p.evaluate(source => window.eval(source), source);
        assert.equal(await p.evaluate(() => !!document.getElementById('chatgpt-response-favicon-diagnostics')), false);
        await open(p); await p.evaluate(() => window.__chatgptResponseFaviconV2.dispose());
        assert.equal(await p.evaluate(() => !!document.getElementById('chatgpt-response-favicon-diagnostics')), false);
    }));
    await test('Modal failure removes the incomplete view and retains the full console diagnosis', () => using(usage(), async p => {
        await p.evaluate(() => {
            console.info = (label, data) => { window.loggedDiagnostic = data; };
            HTMLDialogElement.prototype.showModal = () => { throw Error('Modal unavailable'); };
        });
        await open(p);
        const d = await p.evaluate(() => ({ exists: !!document.getElementById('chatgpt-response-favicon-diagnostics'),
            version: window.loggedDiagnostic.version, alerts: window.testAlerts }));
        assert.equal(d.exists, false); assert.equal(d.version, '1.5.8'); assert.equal(d.alerts.length, 1);
    }));
    const output = { sourceSHA256: crypto.createHash('sha256').update(source).digest('hex'), runtime: process.version,
        jsdom: require('jsdom/package.json').version, scope: 'Synthetic DOM; native dialog API mocked here and tested separately in isolated Chromium',
        passed: results.filter(r => r.result === 'PASS').length, total: results.length, results };
    fs.writeFileSync(__dirname + '/diagnostic-dialog-results.json', JSON.stringify(output, null, 2) + '\n', { flag: 'wx' });
    console.log(`${output.passed}/${output.total} passed`); process.exitCode = output.passed === output.total ? 0 : 1;
})().catch(error => { console.error(error); process.exitCode = 1; });
