'use strict';
// Isolated browser and synthetic HTML only. No signed-in session or live ChatGPT traffic.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { chromium } = require('playwright');
const source = fs.readFileSync(path.join(__dirname, 'verification/candidate-1.5.8/chatgpt-response-favicon.user.js'), 'utf8');
const output = fs.mkdtempSync(path.join(os.tmpdir(), 'crn-v156-browser-'));
const results = [];
let browser;
async function test(name, fn) {
    try { const evidence = await fn(); results.push({ name, result: 'PASS', evidence }); console.log('PASS', name); }
    catch (error) { results.push({ name, result: 'FAIL', error: error.stack }); console.error('FAIL', name, error); }
}
(async () => {
    browser = await chromium.launch({ headless: true,
        ...(process.env.CRN_BROWSER_PATH ? { executablePath: process.env.CRN_BROWSER_PATH } : {}),
        args: ['--no-sandbox'] });
    const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
    // Read permission is used only to compare the synthetic test's copied text.
    await context.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://chatgpt.com' });
    const page = await context.newPage();
    const errors = []; page.on('pageerror', error => errors.push(String(error)));
    await page.route('**/*', route => route.fulfill({ contentType: 'text/html', body: `<!doctype html>
        <html lang="ja"><head><meta charset="utf-8"><title>Isolated usage fixture</title>
        <style>body{font:16px system-ui;background:#f1f5f9;margin:40px;color:#1e293b}main{max-width:800px;margin:auto}section{background:white;padding:20px;margin:15px 0;border-radius:10px}textarea{width:90%;height:60px}</style>
        </head><body><main><h1>使用状況（合成データ）</h1><section><h2>5時間ごとの利用上限</h2><p>残り54%</p></section>
        <section><h2>週ごとの利用上限</h2><p>残り2%</p></section><textarea id="draft">入力欄の保護確認用。送信しません。</textarea></main></body></html>` }));
    await page.goto('https://chatgpt.com/settings/usage?tab=overview');
    await page.evaluate(source => {
        window.testNotifications = []; window.testMenus = {};
        window.GM_notification = data => window.testNotifications.push(data);
        window.GM_getValue = (key, fallback) => fallback;
        window.GM_registerMenuCommand = (label, handler) => { window.testMenus[label] = handler; return label; };
        window.GM_unregisterMenuCommand = label => delete window.testMenus[label];
        const now = Date.now();
        const events = Array.from({ length: 48 }, (_, i) => ({ event: 'sample', at: now - (48 - i) * 15000,
            runStartedAt: now - 900000, routeKind: 'usage-path', visibility: 'hidden', status: 'recognized',
            reloadBlockedBy: 'unsent-input', recoveryCoordination: 'idle', navigationType: 'reload',
            snapshotAt: now - (48 - i) * 15000, reloadDueAt: now - 840000, online: true, sending: false, wasDiscarded: false,
            rows: [{ key: 'hours-5', state: 'available', remaining: 54 }, { key: 'weekly', state: 'available', remaining: 2 }],
            blockedBefore: [], gap: null }));
        sessionStorage.setItem('chatgpt-response-favicon:usage-trace:v1', JSON.stringify({ version: 1, updatedAt: now, events, lastHidden: events.at(-1) }));
        window.eval(source);
    }, source);
    const field = page.getByRole('textbox', { name: '診断JSONの全文' });
    await test('Native modal preserves and copies more than 2000 characters in full', async () => {
        await page.locator('#draft').focus();
        await page.keyboard.press('Alt+Shift+U');
        await field.waitFor({ state: 'visible' });
        const value = await field.inputValue(); const data = JSON.parse(value);
        assert.ok(value.length > 2000); assert.equal(data.version, '1.5.8'); assert.equal(data.usageTrace.events.length, 48);
        const selection = await field.evaluate(el => ({ start: el.selectionStart, end: el.selectionEnd, readOnly: el.readOnly }));
        assert.deepEqual(selection, { start: 0, end: value.length, readOnly: true });
        await page.keyboard.press('Control+c');
        const clipboard = await page.evaluate(() => navigator.clipboard.readText());
        assert.equal(clipboard, value);
        await page.screenshot({ path: path.join(output, 'desktop.png') });
        return { characters: value.length, clipboardMatches: true, validJSON: true };
    });
    await test('Native Escape closes the view and restores unchanged draft focus', async () => {
        const before = await page.locator('#draft').inputValue(); const diagnostic = await field.inputValue();
        await page.keyboard.press('Enter'); assert.equal(await field.inputValue(), diagnostic);
        await page.keyboard.press('Escape');
        await page.locator('#chatgpt-response-favicon-diagnostics').waitFor({ state: 'detached' });
        assert.equal(await page.evaluate(() => document.activeElement.id), 'draft');
        assert.equal(await page.locator('#draft').inputValue(), before);
        assert.equal(await page.evaluate(() => window.testNotifications.length), 0);
        return { focusRestored: true, draftPreserved: true, noNotification: true };
    });
    await test('Repeated shortcut replaces the modal, and the close button removes it', async () => {
        await page.keyboard.press('Alt+Shift+U'); await field.waitFor({ state: 'visible' });
        await page.keyboard.press('Alt+Shift+U'); await field.waitFor({ state: 'visible' });
        assert.equal(await page.locator('#chatgpt-response-favicon-diagnostics').count(), 1);
        await field.evaluate(el => el.setSelectionRange(1, 8));
        await page.getByRole('button', { name: '全文を選択', exact: true }).click();
        const selection = await field.evaluate(el => ({ start: el.selectionStart, end: el.selectionEnd, length: el.value.length }));
        assert.equal(selection.start, 0); assert.equal(selection.end, selection.length);
        await page.getByRole('button', { name: '閉じる', exact: true }).click();
        await page.locator('#chatgpt-response-favicon-diagnostics').waitFor({ state: 'detached' });
        return { singleModal: true, selectionRestored: true, removedOnClose: true };
    });
    await test('Narrow viewport remains usable and monitoring continues while modal is open', async () => {
        await page.setViewportSize({ width: 390, height: 844 });
        await page.keyboard.press('Alt+Shift+U'); await field.waitFor({ state: 'visible' });
        const box = await page.getByRole('dialog').boundingBox();
        assert.ok(box.x >= 0 && box.y >= 0 && box.x + box.width <= 391 && box.y + box.height <= 845);
        const before = await page.evaluate(() => window.__chatgptResponseFaviconV2.inspectUsage().lifecycle.lastCheckAt);
        await page.waitForFunction(before => window.__chatgptResponseFaviconV2.inspectUsage().lifecycle.lastCheckAt > before + 1000, before);
        await page.keyboard.press('Tab');
        assert.equal(await page.evaluate(() => document.activeElement.id), 'chatgpt-response-favicon-diagnostics');
        await page.screenshot({ path: path.join(output, 'narrow.png') });
        await page.keyboard.press('Escape');
        assert.deepEqual(errors, []);
        return { viewport: '390x844', dialogInsideViewport: true, monitoringContinues: true, scriptErrors: 0 };
    });
    const report = { sourceSHA256: crypto.createHash('sha256').update(source).digest('hex'), browser: browser.version(),
        platform: process.platform, runtime: process.version, playwright: require('playwright/package.json').version,
        scope: 'Isolated headless Chromium, synthetic page and history, GM APIs mocked; no live account or Windows/Tampermonkey validation',
        passed: results.filter(r => r.result === 'PASS').length, total: results.length, results };
    fs.writeFileSync(path.join(output, 'browser-results.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
    console.log(`${report.passed}/${report.total} passed`); console.log('Browser verification directory:', output);
    process.exitCode = report.passed === report.total ? 0 : 1;
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(async () => { await browser?.close(); });
